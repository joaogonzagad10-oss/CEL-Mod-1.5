package com.zootopia.rpg.common;

import java.util.UUID;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * Raças jogáveis e constantes de balanceamento.
 *
 * Unidade usada pelo usuário: "vida 20" = 20 corações (40 pontos de vida do jogo),
 * "garra 6" = 6 corações (12 pontos), "mordida 8" = 8 corações (16 pontos).
 * Se quiser outro valor, é só mexer aqui (valores em PONTOS de vida; 2 pontos = 1 coração).
 */
public final class Race {
    public static final int NONE = 0;
    public static final int DOG = 1;
    public static final int WOLF = 2;

    public static final String KEY = "zootopiarpg_race";
    public static final UUID HEALTH_ID = UUID.fromString("5e1d2a9c-6b0f-4c1e-9d55-7a1c0b2f3a11");

    /** Vida normal do jogador = 20 pontos. +20 => 40 pontos = 20 corações. */
    public static final double BONUS_HEALTH = 20.0D;
    /** Dano da garra (pontos). 12 = 6 corações. */
    public static final float CLAW_DAMAGE = 12.0F;

    /** 10 segundos ativo, 5 segundos de recarga (em ticks). */
    public static final int SCENT_ACTIVE_TICKS = 200;
    public static final int SCENT_COOLDOWN_TICKS = 100;
    /** 6 chunks = 96 blocos. */
    public static final double SCENT_RANGE = 96.0D;

    private Race() {}

    /** Só confiável no servidor (no cliente use ClientRace). */
    public static int get(Player p) {
        return p.getPersistentData().getInt(KEY);
    }

    public static void set(Player p, int race) {
        p.getPersistentData().putInt(KEY, race);
    }

    /** Garante o bônus permanente de vida de quem já escolheu uma raça. */
    public static void ensureHealth(Player p) {
        AttributeInstance inst = p.getAttribute(Attributes.MAX_HEALTH);
        if (inst == null) return;
        if (get(p) != NONE && inst.getModifier(HEALTH_ID) == null) {
            inst.addPermanentModifier(new AttributeModifier(HEALTH_ID, "Zootopia race health",
                    BONUS_HEALTH, AttributeModifier.Operation.ADDITION));
        }
    }
}
