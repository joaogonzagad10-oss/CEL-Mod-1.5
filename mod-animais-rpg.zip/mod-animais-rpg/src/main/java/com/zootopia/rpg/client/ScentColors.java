package com.zootopia.rpg.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;

/** Cor do nome de cada mob no farejar/ouvir. Mobs de outros mods caem na cor da categoria. */
public final class ScentColors {
    private static final Map<String, Integer> BY_ID = new HashMap<>();

    static {
        BY_ID.put("zombie", 0x55FF55);
        BY_ID.put("husk", 0x55FF55);
        BY_ID.put("drowned", 0x55FF55);
        BY_ID.put("zombie_villager", 0x55FF55);
        BY_ID.put("creeper", 0x5555FF);
        BY_ID.put("skeleton", 0xFFFFFF);
        BY_ID.put("stray", 0xDDEEFF);
        BY_ID.put("spider", 0xAA0000);
        BY_ID.put("cave_spider", 0xCC2222);
        BY_ID.put("enderman", 0xAA44FF);
        BY_ID.put("warden", 0x1AD6D6);
        BY_ID.put("ender_dragon", 0xD000FF);
        BY_ID.put("wither", 0x8A8A8A);
        BY_ID.put("witch", 0xAA55AA);
        BY_ID.put("blaze", 0xFF9900);
        BY_ID.put("ghast", 0xF2F2F2);
        BY_ID.put("slime", 0x77FF77);
        BY_ID.put("magma_cube", 0xFF6A00);
        BY_ID.put("cow", 0xB5793F);
        BY_ID.put("mooshroom", 0xD04040);
        BY_ID.put("chicken", 0xFFF2A8);
        BY_ID.put("pig", 0xFFAAC8);
        BY_ID.put("sheep", 0xFFFFFF);
        BY_ID.put("horse", 0xC49A6C);
        BY_ID.put("villager", 0xD9A066);
        BY_ID.put("iron_golem", 0xD0D0D0);
        BY_ID.put("wolf", 0xB8C0CC);
        BY_ID.put("cat", 0xFFB347);
        BY_ID.put("bee", 0xFFD83A);
        BY_ID.put("zootopiarpg:good_lion", 0xFFD700);
        BY_ID.put("zootopiarpg:evil_lion", 0xFF2020);
    }

    private ScentColors() {}

    public static int color(LivingEntity e) {
        var key = EntityType.getKey(e.getType());
        Integer c = BY_ID.get(key.getNamespace().equals("minecraft") ? key.getPath() : key.toString());
        if (c != null) return c;
        MobCategory cat = e.getType().getCategory();
        switch (cat) {
            case MONSTER:
                return 0xFF5555;
            case CREATURE:
                return 0xFFD966;
            case AMBIENT:
                return 0xBBBBBB;
            case WATER_CREATURE:
            case WATER_AMBIENT:
            case UNDERGROUND_WATER_CREATURE:
                return 0x55FFFF;
            default:
                return 0xFFFFFF;
        }
    }
}
