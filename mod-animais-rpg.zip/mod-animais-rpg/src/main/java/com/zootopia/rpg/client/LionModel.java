package com.zootopia.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.zootopia.rpg.entity.AbstractLion;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Modelo do leão (textura 128x64).
 * UVs: corpo (0,0) | juba (54,0) | cabeça (90,0) | focinho (90,16) | mandíbula (108,16)
 *      orelha (90,26) | perna (0,28) | rabo (16,28) | tufo (40,28) | espinho (52,28)
 */
public class LionModel extends EntityModel<AbstractLion> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart jaw;
    private final ModelPart tail;
    private final ModelPart legFR;
    private final ModelPart legFL;
    private final ModelPart legBR;
    private final ModelPart legBL;
    private final ModelPart[] spikes = new ModelPart[3];

    public LionModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.jaw = head.getChild("jaw");
        this.tail = root.getChild("tail");
        this.legFR = root.getChild("leg_fr");
        this.legFL = root.getChild("leg_fl");
        this.legBR = root.getChild("leg_br");
        this.legBL = root.getChild("leg_bl");
        ModelPart body = root.getChild("body");
        for (int i = 0; i < 3; i++) {
            spikes[i] = body.getChild("spike" + i);
        }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-5.0F, -4.0F, -9.0F, 10.0F, 9.0F, 17.0F), PartPose.offset(0.0F, 10.0F, 0.0F));
        for (int i = 0; i < 3; i++) {
            body.addOrReplaceChild("spike" + i, CubeListBuilder.create().texOffs(52, 28)
                    .addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offset(0.0F, -4.0F, -4.0F + i * 5.0F));
        }

        root.addOrReplaceChild("mane", CubeListBuilder.create().texOffs(54, 0)
                .addBox(-6.0F, -6.0F, -3.0F, 12.0F, 12.0F, 6.0F), PartPose.offset(0.0F, 10.0F, -8.0F));

        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(90, 0)
                .addBox(-4.0F, -4.0F, -7.0F, 8.0F, 8.0F, 7.0F), PartPose.offset(0.0F, 8.0F, -9.0F));
        head.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(90, 16)
                .addBox(-2.5F, -1.0F, -4.0F, 5.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 1.0F, -7.0F));
        head.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(108, 16)
                .addBox(-2.5F, 0.0F, -4.0F, 5.0F, 2.0F, 4.0F), PartPose.offset(0.0F, 4.0F, -7.0F));
        head.addOrReplaceChild("ear_r", CubeListBuilder.create().texOffs(90, 26)
                .addBox(-1.0F, -2.0F, -0.5F, 2.0F, 2.0F, 1.0F), PartPose.offset(-3.0F, -4.0F, -3.0F));
        head.addOrReplaceChild("ear_l", CubeListBuilder.create().texOffs(90, 26).mirror()
                .addBox(-1.0F, -2.0F, -0.5F, 2.0F, 2.0F, 1.0F), PartPose.offset(3.0F, -4.0F, -3.0F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 28).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 9.0F, 4.0F);
        CubeListBuilder legM = CubeListBuilder.create().texOffs(0, 28).mirror().addBox(-2.0F, 0.0F, -2.0F, 4.0F, 9.0F, 4.0F);
        root.addOrReplaceChild("leg_fr", leg, PartPose.offset(-3.5F, 15.0F, -6.5F));
        root.addOrReplaceChild("leg_fl", legM, PartPose.offset(3.5F, 15.0F, -6.5F));
        root.addOrReplaceChild("leg_br", leg, PartPose.offset(-3.5F, 15.0F, 6.5F));
        root.addOrReplaceChild("leg_bl", legM, PartPose.offset(3.5F, 15.0F, 6.5F));

        PartDefinition tail = root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(16, 28)
                .addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 7.0F, 8.0F, 0.5F, 0.0F, 0.0F));
        tail.addOrReplaceChild("tuft", CubeListBuilder.create().texOffs(40, 28)
                .addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 3.0F), PartPose.offset(0.0F, 0.0F, 10.0F));

        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(AbstractLion e, float limbSwing, float limbSwingAmount, float age,
                          float netHeadYaw, float headPitch) {
        float partial = age - e.tickCount;

        head.xRot = headPitch * Mth.DEG_TO_RAD;
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        jaw.xRot = 0.05F;

        float walk = Mth.cos(limbSwing * 0.6662F) * 1.3F * limbSwingAmount;
        legFR.xRot = walk;
        legBL.xRot = walk;
        legFL.xRot = -walk;
        legBR.xRot = -walk;

        // mordida: a cabeça avança e a mandíbula abre e fecha rápido
        if (e.biteAnim > 0) {
            float p = Mth.clamp((e.biteAnim - partial) / 10.0F, 0.0F, 1.0F);
            float s = Mth.sin(p * Mth.PI);
            head.xRot += s * 0.35F;
            jaw.xRot += s * 0.9F;
        }
        // rugido: cabeça para cima, boca bem aberta e tremendo
        if (e.roarAnim > 0) {
            float p = Mth.clamp((e.roarAnim - partial) / 40.0F, 0.0F, 1.0F);
            float s = Mth.clamp(Mth.sin(p * Mth.PI) * 1.6F, 0.0F, 1.0F);
            head.xRot -= s * 0.7F;
            jaw.xRot += s * 1.0F;
            head.yRot += Mth.sin(age * 1.8F) * 0.08F * s;
        }

        tail.yRot = Mth.sin(age * 0.1F) * 0.3F;
        tail.xRot = 0.5F + limbSwingAmount * 0.3F;

        for (ModelPart spike : spikes) {
            spike.visible = e.isEvil();
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay,
                               float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
