package com.zootopia.rpg.client;

import java.util.UUID;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;

/** Pontes chamadas pelos pacotes (só carregadas no cliente). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void setRace(UUID id, int race) {
        int before = ClientRace.get(id);
        ClientRace.set(id, race);
        Minecraft mc = Minecraft.getInstance();
        // ao escolher a raça, a câmera começa em 3ª pessoa (a tecla V alterna para 1ª pessoa)
        if (mc.player != null && mc.player.getUUID().equals(id) && race != 0) {
            ClientRace.mustChoose = false;
            if (before == 0) mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
        }
    }

    public static void openChoice() {
        Minecraft mc = Minecraft.getInstance();
        ClientRace.mustChoose = true;
        if (!(mc.screen instanceof RaceSelectScreen)) {
            mc.setScreen(new RaceSelectScreen());
        }
    }
}
