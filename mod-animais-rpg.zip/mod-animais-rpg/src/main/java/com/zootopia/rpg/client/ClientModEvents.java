package com.zootopia.rpg.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.zootopia.rpg.ModEntities;
import com.zootopia.rpg.ZootopiaRPG;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ZootopiaRPG.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final ModelLayerLocation LION =
            new ModelLayerLocation(new ResourceLocation(ZootopiaRPG.MODID, "lion"), "main");
    public static final ModelLayerLocation ANIMAL_PLAYER =
            new ModelLayerLocation(new ResourceLocation(ZootopiaRPG.MODID, "animal_player"), "main");

    public static final KeyMapping SCENT_KEY = new KeyMapping("key.zootopiarpg.scent",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.zootopiarpg");
    public static final KeyMapping CAMERA_KEY = new KeyMapping("key.zootopiarpg.camera",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.zootopiarpg");

    /** Renderizador usado no lugar do jogador normal (criado quando os modelos são carregados). */
    public static AnimalPlayerRenderer playerRenderer;

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent e) {
        ClientRegistry.registerKeyBinding(SCENT_KEY);
        ClientRegistry.registerKeyBinding(CAMERA_KEY);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(LION, LionModel::createBodyLayer);
        e.registerLayerDefinition(ANIMAL_PLAYER, AnimalPlayerModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.GOOD_LION.get(), LionRenderer::new);
        e.registerEntityRenderer(ModEntities.EVIL_LION.get(), LionRenderer::new);
    }

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        Minecraft mc = Minecraft.getInstance();
        EntityRendererProvider.Context ctx = new EntityRendererProvider.Context(
                mc.getEntityRenderDispatcher(), mc.getItemRenderer(), mc.getResourceManager(),
                e.getEntityModels(), mc.font);
        playerRenderer = new AnimalPlayerRenderer(ctx);
    }
}
