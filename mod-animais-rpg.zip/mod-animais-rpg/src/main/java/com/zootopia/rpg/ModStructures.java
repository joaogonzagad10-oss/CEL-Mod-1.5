package com.zootopia.rpg;

import com.zootopia.rpg.world.CastleFeature;
import com.zootopia.rpg.world.CastlePiece;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModStructures {
    public static final DeferredRegister<StructureFeature<?>> STRUCTURES =
            DeferredRegister.create(ForgeRegistries.STRUCTURE_FEATURES, ZootopiaRPG.MODID);

    public static final RegistryObject<StructureFeature<NoneFeatureConfiguration>> BLACK_CASTLE =
            STRUCTURES.register("black_castle", () -> new CastleFeature(false));
    public static final RegistryObject<StructureFeature<NoneFeatureConfiguration>> EVIL_CASTLE =
            STRUCTURES.register("evil_castle", () -> new CastleFeature(true));

    public static StructurePieceType CASTLE_PIECE;

    public static void setup() {
        CASTLE_PIECE = Registry.register(Registry.STRUCTURE_PIECE,
                new ResourceLocation(ZootopiaRPG.MODID, "castle"), CastlePiece::new);
        StructureFeature.STEP.put(BLACK_CASTLE.get(), GenerationStep.Decoration.SURFACE_STRUCTURES);
        StructureFeature.STEP.put(EVIL_CASTLE.get(), GenerationStep.Decoration.SURFACE_STRUCTURES);
    }
}
