package com.zootopia.rpg.client;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Estado do lado do cliente: raça de cada jogador e relógios das habilidades. */
public final class ClientRace {
    private static final Map<UUID, Integer> RACES = new HashMap<>();
    private static final Map<UUID, Integer> PREVIEW = new HashMap<>();

    /** Ticks restantes do farejar/ouvir ativo e da recarga. */
    public static int scentActive = 0;
    public static int scentCooldown = 0;
    /** Ticks restantes da animação de arranhão na tela (1ª pessoa). */
    public static int slash = 0;
    /** Verdadeiro enquanto o servidor ainda espera este jogador escolher a raça. */
    public static boolean mustChoose = false;

    private ClientRace() {}

    public static int get(UUID id) {
        Integer p = PREVIEW.get(id);
        if (p != null) return p;
        return RACES.getOrDefault(id, 0);
    }

    public static void set(UUID id, int race) {
        RACES.put(id, race);
    }

    public static void setPreview(UUID id, int race) {
        PREVIEW.put(id, race);
    }

    public static void clearPreview(UUID id) {
        PREVIEW.remove(id);
    }

    public static void clearAll() {
        RACES.clear();
        PREVIEW.clear();
        scentActive = 0;
        scentCooldown = 0;
        slash = 0;
        mustChoose = false;
    }
}
