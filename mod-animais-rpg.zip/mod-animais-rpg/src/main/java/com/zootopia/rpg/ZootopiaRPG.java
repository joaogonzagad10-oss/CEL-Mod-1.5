package com.zootopia.rpg;

import com.zootopia.rpg.common.Net;
import com.zootopia.rpg.common.ServerEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ZootopiaRPG.MODID)
public class ZootopiaRPG {
    public static final String MODID = "zootopiarpg";

    public ZootopiaRPG() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModStructures.STRUCTURES.register(bus);
        bus.addListener(ModEntities::registerAttributes);
        bus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(new ServerEvents());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            Net.register();
            ModStructures.setup();
        });
    }
}
