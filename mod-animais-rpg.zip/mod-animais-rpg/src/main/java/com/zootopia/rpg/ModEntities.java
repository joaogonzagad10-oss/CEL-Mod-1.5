package com.zootopia.rpg;

import com.zootopia.rpg.entity.AbstractLion;
import com.zootopia.rpg.entity.EvilLion;
import com.zootopia.rpg.entity.GoodLion;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, ZootopiaRPG.MODID);

    public static final RegistryObject<EntityType<GoodLion>> GOOD_LION = ENTITIES.register("good_lion",
            () -> EntityType.Builder.of(GoodLion::new, MobCategory.CREATURE)
                    .sized(1.4F, 1.7F).clientTrackingRange(10)
                    .build(ZootopiaRPG.MODID + ":good_lion"));

    public static final RegistryObject<EntityType<EvilLion>> EVIL_LION = ENTITIES.register("evil_lion",
            () -> EntityType.Builder.of(EvilLion::new, MobCategory.CREATURE)
                    .sized(1.4F, 1.7F).clientTrackingRange(10)
                    .build(ZootopiaRPG.MODID + ":evil_lion"));

    public static void registerAttributes(EntityAttributeCreationEvent e) {
        e.put(GOOD_LION.get(), AbstractLion.attributes(AbstractLion.GOOD_BITE).build());
        e.put(EVIL_LION.get(), AbstractLion.attributes(AbstractLion.EVIL_BITE).build());
    }
}
