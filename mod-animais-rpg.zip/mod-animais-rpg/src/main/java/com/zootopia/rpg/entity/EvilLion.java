package com.zootopia.rpg.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Leão maligno: preto, olhos vermelhos, morde (8 corações) e ruge empurrando ~6 blocos. */
public class EvilLion extends AbstractLion {
    public EvilLion(EntityType<? extends EvilLion> type, Level level) {
        super(type, level);
    }

    @Override
    public boolean isEvil() {
        return true;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WOLF_GROWL;
    }
}
