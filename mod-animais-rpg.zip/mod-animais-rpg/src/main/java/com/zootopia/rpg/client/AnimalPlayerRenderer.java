package com.zootopia.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Vector3f;
import com.zootopia.rpg.ZootopiaRPG;
import com.zootopia.rpg.common.Race;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.CustomHeadLayer;
import net.minecraft.client.renderer.entity.layers.ElytraLayer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.phys.Vec3;

/** Renderiza jogadores que escolheram cachorro/lobo no lugar da skin normal. */
public class AnimalPlayerRenderer extends LivingEntityRenderer<AbstractClientPlayer, AnimalPlayerModel> {
    private static final ResourceLocation DOG = new ResourceLocation(ZootopiaRPG.MODID, "textures/entity/dog.png");
    private static final ResourceLocation WOLF = new ResourceLocation(ZootopiaRPG.MODID, "textures/entity/wolf.png");

    public AnimalPlayerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new AnimalPlayerModel(ctx.bakeLayer(ClientModEvents.ANIMAL_PLAYER)), 0.5F);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));
        this.addLayer(new ItemInHandLayer<>(this));
        this.addLayer(new CustomHeadLayer<>(this, ctx.getModelSet()));
        this.addLayer(new ElytraLayer<>(this, ctx.getModelSet()));
    }

    @Override
    public ResourceLocation getTextureLocation(AbstractClientPlayer p) {
        return ClientRace.get(p.getUUID()) == Race.WOLF ? WOLF : DOG;
    }

    @Override
    public void render(AbstractClientPlayer p, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        setModelProperties(p);
        super.render(p, yaw, pt, ps, buf, light);
    }

    @Override
    protected void scale(AbstractClientPlayer p, PoseStack ps, float pt) {
        ps.scale(0.9375F, 0.9375F, 0.9375F);
    }

    /** Mão em primeira pessoa (cópia adaptada do PlayerRenderer). */
    public void renderHand(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, boolean right) {
        AnimalPlayerModel m = this.getModel();
        setModelProperties(p);
        m.attackTime = 0.0F;
        m.crouching = false;
        m.swimAmount = 0.0F;
        m.setupAnim(p, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
        ModelPart arm = right ? m.rightArm : m.leftArm;
        arm.xRot = 0.0F;
        arm.render(ps, buf.getBuffer(RenderType.entitySolid(getTextureLocation(p))), light, OverlayTexture.NO_OVERLAY);
    }

    private void setModelProperties(AbstractClientPlayer p) {
        AnimalPlayerModel m = this.getModel();
        if (p.isSpectator()) {
            m.setAllVisible(false);
            m.head.visible = true;
        } else {
            m.setAllVisible(true);
            m.hat.visible = false;
            m.crouching = p.isCrouching();
            HumanoidModel.ArmPose main = getArmPose(p, InteractionHand.MAIN_HAND);
            HumanoidModel.ArmPose off = getArmPose(p, InteractionHand.OFF_HAND);
            if (main.isTwoHanded()) {
                off = p.getOffhandItem().isEmpty() ? HumanoidModel.ArmPose.EMPTY : HumanoidModel.ArmPose.ITEM;
            }
            if (p.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT) {
                m.rightArmPose = main;
                m.leftArmPose = off;
            } else {
                m.rightArmPose = off;
                m.leftArmPose = main;
            }
        }
    }

    private static HumanoidModel.ArmPose getArmPose(AbstractClientPlayer p, InteractionHand hand) {
        ItemStack s = p.getItemInHand(hand);
        if (s.isEmpty()) return HumanoidModel.ArmPose.EMPTY;
        if (p.getUsedItemHand() == hand && p.getUseItemRemainingTicks() > 0) {
            UseAnim u = s.getUseAnimation();
            if (u == UseAnim.BLOCK) return HumanoidModel.ArmPose.BLOCK;
            if (u == UseAnim.BOW) return HumanoidModel.ArmPose.BOW_AND_ARROW;
            if (u == UseAnim.SPEAR) return HumanoidModel.ArmPose.THROW_SPEAR;
            if (u == UseAnim.CROSSBOW) return HumanoidModel.ArmPose.CROSSBOW_CHARGE;
            if (u == UseAnim.SPYGLASS) return HumanoidModel.ArmPose.SPYGLASS;
        } else if (!p.swinging && s.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(s)) {
            return HumanoidModel.ArmPose.CROSSBOW_HOLD;
        }
        return HumanoidModel.ArmPose.ITEM;
    }

    @Override
    protected void setupRotations(AbstractClientPlayer p, PoseStack ps, float age, float yaw, float pt) {
        float swim = p.getSwimAmount(pt);
        if (p.isFallFlying()) {
            super.setupRotations(p, ps, age, yaw, pt);
            float f = (float) p.getFallFlyingTicks() + pt;
            float f1 = Mth.clamp(f * f / 100.0F, 0.0F, 1.0F);
            if (!p.isAutoSpinAttack()) {
                ps.mulPose(Vector3f.XP.rotationDegrees(f1 * (-90.0F - p.getXRot())));
            }
            Vec3 view = p.getViewVector(pt);
            Vec3 move = p.getDeltaMovement();
            double d0 = move.horizontalDistanceSqr();
            double d1 = view.horizontalDistanceSqr();
            if (d0 > 0.0D && d1 > 0.0D) {
                double d2 = (move.x * view.x + move.z * view.z) / Math.sqrt(d0 * d1);
                double d3 = move.x * view.z - move.z * view.x;
                ps.mulPose(Vector3f.YP.rotation((float) (Math.signum(d3) * Math.acos(d2))));
            }
        } else if (swim > 0.0F) {
            super.setupRotations(p, ps, age, yaw, pt);
            float target = p.isInWater() ? -90.0F - p.getXRot() : -90.0F;
            ps.mulPose(Vector3f.XP.rotationDegrees(Mth.lerp(swim, 0.0F, target)));
            if (p.isVisuallySwimming()) {
                ps.translate(0.0D, -1.0D, 0.3D);
            }
        } else {
            super.setupRotations(p, ps, age, yaw, pt);
        }
    }
}
