package com.zootopia.rpg;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ZootopiaRPG.MODID);

    public static final RegistryObject<Item> GOOD_LION_EGG = ITEMS.register("good_lion_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.GOOD_LION, 0xE0B050, 0x4A2E10,
                    new Item.Properties().tab(CreativeModeTab.TAB_MISC)));

    public static final RegistryObject<Item> EVIL_LION_EGG = ITEMS.register("evil_lion_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.EVIL_LION, 0x26222A, 0xC01820,
                    new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
}
