package com.zootopia.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Matrix4f;
import com.zootopia.rpg.common.Race;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Desenha o nome (colorido) de todos os seres vivos num raio de 6 chunks, inclusive atrás de blocos. */
public final class ScentRenderer {
    private static final int MAX_LABELS = 80;

    private ScentRenderer() {}

    public static void render(PoseStack ps, float partial) {
        if (ClientRace.scentActive <= 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 cp = cam.getPosition();
        Font font = mc.font;
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        int count = 0;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || le == mc.player || !le.isAlive()) continue;
            double dist = le.distanceTo(mc.player);
            if (dist > Race.SCENT_RANGE) continue;
            if (++count > MAX_LABELS) break;

            Component name = le.getType().getDescription();
            int color = 0xFF000000 | ScentColors.color(le);

            double x = Mth.lerp(partial, le.xOld, le.getX()) - cp.x;
            double y = Mth.lerp(partial, le.yOld, le.getY()) + le.getBbHeight() + 0.6D - cp.y;
            double z = Mth.lerp(partial, le.zOld, le.getZ()) - cp.z;

            ps.pushPose();
            ps.translate(x, y, z);
            ps.mulPose(cam.rotation());
            // quanto mais longe, maior o texto, para dar para ler a 96 blocos
            float s = 0.025F * (float) Math.max(1.0D, dist / 10.0D);
            ps.scale(-s, -s, s);
            Matrix4f m = ps.last().pose();

            font.drawInBatch(name, -font.width(name) / 2.0F, 0.0F, color, false, m, buf, true, 0x66000000, 0xF000F0);
            String d = (int) dist + "m";
            font.drawInBatch(d, -font.width(d) / 2.0F, 10.0F, 0xFFE6E6E6, false, m, buf, true, 0, 0xF000F0);
            ps.popPose();
        }
        buf.endBatch();
    }
}
