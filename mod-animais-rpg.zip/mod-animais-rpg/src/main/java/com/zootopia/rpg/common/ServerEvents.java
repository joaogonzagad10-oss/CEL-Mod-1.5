package com.zootopia.rpg.common;

import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

public class ServerEvents {

    /** Chamado quando o jogador clica numa das duas opções na tela de escolha. */
    public static void choose(ServerPlayer p, int race) {
        if (Race.get(p) != Race.NONE) return;
        if (race != Race.DOG && race != Race.WOLF) return;
        Race.set(p, race);
        Race.ensureHealth(p);
        p.setHealth(p.getMaxHealth());
        Net.CH.send(PacketDistributor.ALL.noArg(), new Net.SyncRace(p.getUUID(), race));
        p.displayClientMessage(new TranslatableComponent(
                race == Race.DOG ? "message.zootopiarpg.chose_dog" : "message.zootopiarpg.chose_wolf"), true);
    }

    private static void syncToEveryone(ServerPlayer p) {
        int r = Race.get(p);
        if (r != Race.NONE) {
            Net.CH.send(PacketDistributor.ALL.noArg(), new Net.SyncRace(p.getUUID(), r));
        } else {
            Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new Net.OpenChoice());
        }
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer sp)) return;
        Race.ensureHealth(sp);
        // manda ao novo jogador a raça de todo mundo que já está online
        for (ServerPlayer other : sp.server.getPlayerList().getPlayers()) {
            int r = Race.get(other);
            if (r != Race.NONE) {
                Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new Net.SyncRace(other.getUUID(), r));
            }
        }
        syncToEveryone(sp);
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone e) {
        Race.set(e.getPlayer(), Race.get(e.getOriginal()));
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer sp)) return;
        Race.ensureHealth(sp);
        sp.setHealth(sp.getMaxHealth());
        syncToEveryone(sp);
    }

    @SubscribeEvent
    public void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer sp)) return;
        Race.ensureHealth(sp);
        syncToEveryone(sp);
    }

    @SubscribeEvent
    public void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof ServerPlayer target && e.getPlayer() instanceof ServerPlayer viewer) {
            int r = Race.get(target);
            if (r != Race.NONE) {
                Net.CH.send(PacketDistributor.PLAYER.with(() -> viewer), new Net.SyncRace(target.getUUID(), r));
            }
        }
    }

    /** Garra: de mãos vazias o dano vira o dano da garra (proporcional ao tempo de recarga do golpe). */
    @SubscribeEvent
    public void onHurt(LivingHurtEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer p)) return;
        if (e.getSource().getDirectEntity() != p || !"player".equals(e.getSource().getMsgId())) return;
        if (Race.get(p) == Race.NONE || !p.getMainHandItem().isEmpty()) return;

        float s = p.getAttackStrengthScale(0.5F);
        float dmg = Race.CLAW_DAMAGE * (0.2F + s * s * 0.8F);
        if (e.getAmount() < dmg) e.setAmount(dmg);

        if (p.level instanceof ServerLevel sl) {
            var t = e.getEntityLiving();
            sl.sendParticles(ParticleTypes.CRIT, t.getX(), t.getY() + t.getBbHeight() * 0.6D, t.getZ(),
                    10, 0.3D, 0.3D, 0.3D, 0.25D);
            sl.sendParticles(ParticleTypes.SWEEP_ATTACK, t.getX(), t.getY() + t.getBbHeight() * 0.6D, t.getZ(),
                    1, 0.0D, 0.0D, 0.0D, 0.0D);
            sl.playSound(null, t.getX(), t.getY(), t.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP,
                    SoundSource.PLAYERS, 1.0F, 0.8F);
        }
    }
}
