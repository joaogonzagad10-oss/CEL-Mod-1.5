package com.zootopia.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.zootopia.rpg.common.Net;
import com.zootopia.rpg.common.Race;
import java.util.UUID;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.TranslatableComponent;

/**
 * Tela obrigatória de escolha: Cachorrinho ou Lobinho.
 * Não fecha com ESC e só some depois que o jogador escolhe uma das duas opções.
 */
public class RaceSelectScreen extends Screen {

    public RaceSelectScreen() {
        super(new TranslatableComponent("screen.zootopiarpg.choose.title"));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int by = this.height - 30;
        this.addRenderableWidget(new Button(cx - 150, by, 140, 20,
                new TranslatableComponent("race.zootopiarpg.dog"), b -> pick(Race.DOG)));
        this.addRenderableWidget(new Button(cx + 10, by, 140, 20,
                new TranslatableComponent("race.zootopiarpg.wolf"), b -> pick(Race.WOLF)));
    }

    private void pick(int race) {
        Net.CH.sendToServer(new Net.ChooseRace(race));
        this.minecraft.setScreen(null);
    }

    private void card(PoseStack ps, int x1, int y1, int x2, int y2) {
        fill(ps, x1, y1, x2, y2, 0xFF0E0906);
        fill(ps, x1 + 1, y1 + 1, x2 - 1, y2 - 1, 0xFFB8892B);
        fill(ps, x1 + 2, y1 + 2, x2 - 2, y2 - 2, 0xF0241A12);
    }

    @Override
    public void render(PoseStack ps, int mx, int my, float pt) {
        this.renderBackground(ps);
        int cx = this.width / 2;
        int top = 28;
        int bottom = this.height - 38;

        drawCenteredString(ps, this.font, this.title, cx, 10, 0xFFD36B);
        card(ps, cx - 160, top, cx - 8, bottom);
        card(ps, cx + 8, top, cx + 160, bottom);

        int scale = Math.max(24, Math.min(50, (this.height - 130) * 10 / 22));
        int feetY = top + 10 + (int) (scale * 1.95F);
        LocalPlayer lp = this.minecraft.player;
        if (lp != null) {
            UUID id = lp.getUUID();
            try {
                ClientRace.setPreview(id, Race.DOG);
                InventoryScreen.renderEntityInInventory(cx - 84, feetY, scale,
                        (float) (cx - 84 - mx), (float) (feetY - scale * 1.4F - my), lp);
                ClientRace.setPreview(id, Race.WOLF);
                InventoryScreen.renderEntityInInventory(cx + 84, feetY, scale,
                        (float) (cx + 84 - mx), (float) (feetY - scale * 1.4F - my), lp);
            } finally {
                ClientRace.clearPreview(id);
            }
        }

        int ty = feetY + 8;
        drawCenteredString(ps, this.font, new TranslatableComponent("race.zootopiarpg.dog"), cx - 84, ty, 0xFFD36B);
        drawCenteredString(ps, this.font, new TranslatableComponent("race.zootopiarpg.wolf"), cx + 84, ty, 0xFFD36B);
        for (int i = 1; i <= 3; i++) {
            drawCenteredString(ps, this.font, new TranslatableComponent("race.zootopiarpg.dog.line" + i),
                    cx - 84, ty + 4 + i * 10, 0xE8E0D0);
            drawCenteredString(ps, this.font, new TranslatableComponent("race.zootopiarpg.wolf.line" + i),
                    cx + 84, ty + 4 + i * 10, 0xE8E0D0);
        }
        super.render(ps, mx, my, pt);
    }
}
