# Zootopia RPG — Parte 1 (Forge 1.18.2)

## Como gerar o .jar (GitHub)
1. Crie um repositório novo no GitHub e envie todo o conteúdo desta pasta.
2. Aba **Actions** > workflow **Build mod** (roda sozinho a cada push).
3. Baixe o artefato `zootopiarpg-jar` e coloque o .jar em `mods` (Forge 1.18.2, Java 17).

## O que tem na Parte 1
- Ao entrar, tela obrigatória: **Cachorrinho** ou **Lobinho** (ESC não fecha; só some ao escolher).
- Corpo bípede (2 patas e 2 mãos) com orelhas, focinho, rabo e garras, e túnica de RPG.
- Vida 20 corações. Garra (mãos vazias): ~6 corações de dano + animação de arranhão.
- **J**: Olfato (cachorro) / Audição (lobo). Mostra nome colorido de todos os seres vivos num raio de
  6 chunks (96 blocos), inclusive atrás de blocos. Dura 10 s, recarga 5 s. Mobs de outros mods entram
  automaticamente (cor pela categoria).
- **V**: alterna 1ª/3ª pessoa (começa em 3ª pessoa).
- HUD RPG (barras de vida/fome/XP/ar, hotbar entalhada, ícone da habilidade) e inventário, mesa de
  trabalho e baú com visual RPG.
- Leão Guardião (do bem) e Leão Sombrio (do mal): 20 corações; mordida com animação; o sombrio ruge e
  empurra ~6 blocos. Ovos de spawn no criativo.
- Castelo preto e cinza (leões guardam portão e portas) e Castelo sombrio (leões pretos).
  Aparecem em biomas de terra firme; para achar: `/locate structure zootopiarpg:black_castle`
  e `/locate structure zootopiarpg:evil_castle`.

## Ajustes rápidos
Valores de dano/vida/tempos estão em `common/Race.java` e `entity/AbstractLion.java`
(2 pontos de vida = 1 coração).
